package co.edu.javeriana.fastbite.model;

/**
 * Entidad que representa un pedido en FastBite.
 * GRASP: Information Expert — conoce sus propios datos y calcula su subtotal.
 * SOLID SRP — responsabilidad única: datos de un pedido.
 */
public class Pedido {

    private String cliente;
    private String producto;
    private int    cantidad;
    private double precioUnitario;

    public Pedido(String cliente, String producto, int cantidad, double precioUnitario) {
        this.cliente        = cliente;
        this.producto       = producto;
        this.cantidad       = cantidad;
        this.precioUnitario = precioUnitario;
    }

    // Getters
    public String getCliente()         { return cliente;        }
    public String getProducto()        { return producto;       }
    public int    getCantidad()        { return cantidad;       }
    public double getPrecioUnitario()  { return precioUnitario; }

    /**
     * GRASP Information Expert: el pedido conoce su precio y cantidad,
     * por lo tanto ES el experto para calcular su propio subtotal.
     */
    public double getSubtotal() {
        return cantidad * precioUnitario;
    }

    @Override
    public String toString() {
        return String.format("%s — %s x%d  $%.0f",
                cliente, producto, cantidad, getSubtotal());
    }
}
