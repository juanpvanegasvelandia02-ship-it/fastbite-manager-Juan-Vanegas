package co.edu.javeriana.fastbite.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Gestiona la colección de pedidos y el catálogo de productos.
 * GRASP Creator      — crea instancias de Pedido (las contiene y tiene su info de inicialización).
 * GRASP Information Expert — conoce todos los pedidos, calcula el total global.
 * SOLID SRP          — responsabilidad única: gestionar la lista de pedidos.
 */
public class GestorPedidos {

    private List<Pedido>        pedidos;
    private Map<String, Double> catalogo;

    public GestorPedidos() {
        this.pedidos  = new ArrayList<>();
        this.catalogo = new LinkedHashMap<>();
        inicializarCatalogo();
    }

    private void inicializarCatalogo() {
        catalogo.put("Hamburguesa Clasica", 9000.0);
        catalogo.put("Hamburguesa Doble",   13500.0);
        catalogo.put("Papas Fritas",         5500.0);
        catalogo.put("Combo Familiar",      35000.0);
        catalogo.put("Bebida Grande",        4000.0);
        catalogo.put("Helado",               3500.0);
    }

    /**
     * GRASP Creator: GestorPedidos crea Pedidos porque:
     *  (1) contiene los objetos Pedido,
     *  (2) tiene la información necesaria para crearlos (precio del catálogo).
     */
    public void agregarPedido(String cliente, String producto, int cantidad) {
        double precio     = catalogo.getOrDefault(producto, 0.0);
        Pedido nuevoPedido = new Pedido(cliente, producto, cantidad, precio);
        pedidos.add(nuevoPedido);
    }

    public void eliminarPedido(Pedido pedido) {
        pedidos.remove(pedido);
    }

    /**
     * Copia defensiva: el llamador no puede modificar la lista interna.
     * Aplica encapsulamiento — nunca exponemos la referencia directa.
     */
    public List<Pedido> getPedidos() {
        return new ArrayList<>(pedidos);
    }

    public List<String> getNombresProductos() {
        return new ArrayList<>(catalogo.keySet());
    }

    /**
     * GRASP Information Expert: GestorPedidos conoce todos los pedidos,
     * por lo tanto ES el experto para calcular el total global.
     */
    public double calcularTotal() {
        double total = 0;
        for (Pedido p : pedidos) {
            total += p.getSubtotal();
        }
        return total;
    }
}
