package co.edu.javeriana.fastbite;

import co.edu.javeriana.fastbite.controller.PedidoController;
import co.edu.javeriana.fastbite.model.GestorPedidos;
import co.edu.javeriana.fastbite.view.PedidoView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Punto de entrada de la aplicación JavaFX.
 * SOLID SRP        — responsabilidad única: ensamblar y conectar los componentes MVC.
 * GRASP Low Coupling — es el único lugar del sistema donde se conocen los tres
 *                      componentes (Modelo, Vista, Controlador) simultáneamente.
 * SOLID DIP        — inyecta las dependencias desde afuera; ningún componente
 *                    se crea a sí mismo ni crea a sus colaboradores.
 */
public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {

        // 1. Crear el modelo
        GestorPedidos gestor = new GestorPedidos();

        // 2. Crear el controlador (recibe el modelo por inyección)
        PedidoController controller = new PedidoController(gestor);

        // 3. Crear la vista (recibe el controlador por inyección)
        PedidoView view = new PedidoView(controller);

        // 4. Configurar y mostrar el Stage
        Scene scene = new Scene(view.getRoot(), 520, 500);
        primaryStage.setTitle("FastBite Order Manager");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
