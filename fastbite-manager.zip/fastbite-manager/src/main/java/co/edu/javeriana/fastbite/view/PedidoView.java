package co.edu.javeriana.fastbite.view;

import co.edu.javeriana.fastbite.controller.PedidoController;
import co.edu.javeriana.fastbite.model.Pedido;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Vista MVC: construye la UI JavaFX y registra los handlers de eventos.
 * SOLID SRP        — responsabilidad única: presentación y captura de eventos.
 * GRASP Low Coupling — solo conoce a PedidoController, nunca a GestorPedidos directamente.
 */
public class PedidoView {

    private final PedidoController controller;

    // Raíz del scene graph
    private VBox root;

    // Controles que necesitamos leer o actualizar
    private TextField         txtCliente;
    private ComboBox<String>  cmbProducto;
    private TextField         txtCantidad;
    private ListView<Pedido>  listPedidos;
    private Label             lblTotal;
    private Label             lblMensaje;

    public PedidoView(PedidoController controller) {
        this.controller = controller;
        construirUI();
    }

    // ── Construcción de la interfaz ────────────────────────────────────────

    private void construirUI() {
        root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #f5f5f5;");

        // Título
        Label titulo = new Label("FastBite Order Manager");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titulo.setTextFill(Color.web("#1F4E79"));

        // Formulario
        GridPane form = construirFormulario();

        // Botón agregar
        Button btnAgregar = new Button("Agregar Pedido");
        btnAgregar.setStyle("-fx-background-color:#2E75B6; -fx-text-fill:white; -fx-font-weight:bold;");
        btnAgregar.setPrefWidth(160);
        btnAgregar.setOnAction(e -> manejarAgregarPedido());

        // Mensaje de validación
        lblMensaje = new Label("");
        lblMensaje.setTextFill(Color.RED);

        // Lista de pedidos
        listPedidos = new ListView<>();
        listPedidos.setPrefHeight(180);

        // Botón eliminar
        Button btnEliminar = new Button("Eliminar Seleccionado");
        btnEliminar.setStyle("-fx-background-color:#C0392B; -fx-text-fill:white;");
        btnEliminar.setPrefWidth(180);
        btnEliminar.setOnAction(e -> manejarEliminarPedido());

        // Total
        lblTotal = new Label("Total acumulado: $0");
        lblTotal.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lblTotal.setTextFill(Color.web("#1E6B2E"));

        root.getChildren().addAll(
                titulo,
                form,
                btnAgregar,
                lblMensaje,
                new Separator(),
                listPedidos,
                btnEliminar,
                lblTotal
        );
    }

    private GridPane construirFormulario() {
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(8);
        form.setPadding(new Insets(12));
        form.setStyle("-fx-background-color: white; -fx-border-color: #cccccc; -fx-border-radius: 4;");

        txtCliente = new TextField();
        txtCliente.setPromptText("Nombre del cliente");
        txtCliente.setPrefWidth(220);

        cmbProducto = new ComboBox<>();
        cmbProducto.getItems().addAll(controller.getProductosDisponibles());
        cmbProducto.setPromptText("Seleccione un producto");
        cmbProducto.setPrefWidth(220);

        txtCantidad = new TextField("1");
        txtCantidad.setPrefWidth(60);

        form.add(new Label("Cliente:"),  0, 0);
        form.add(txtCliente,             1, 0);
        form.add(new Label("Producto:"), 0, 1);
        form.add(cmbProducto,            1, 1);
        form.add(new Label("Cantidad:"), 0, 2);
        form.add(txtCantidad,            1, 2);

        return form;
    }

    // ── Handlers de eventos ────────────────────────────────────────────────

    private void manejarAgregarPedido() {
        boolean exito = controller.agregarPedido(
                txtCliente.getText(),
                cmbProducto.getValue(),
                txtCantidad.getText()
        );

        if (exito) {
            lblMensaje.setText("");
            txtCliente.clear();
            cmbProducto.setValue(null);
            txtCantidad.setText("1");
            actualizarVista();
        } else {
            lblMensaje.setText("Error: verifique que todos los campos sean validos.");
        }
    }

    private void manejarEliminarPedido() {
        Pedido seleccionado = listPedidos.getSelectionModel().getSelectedItem();
        controller.eliminarPedido(seleccionado);
        actualizarVista();
    }

    /**
     * Refresca la ListView y el label del total consultando al controlador.
     * La vista nunca accede directamente al modelo — solo habla con el controller.
     */
    private void actualizarVista() {
        ObservableList<Pedido> items =
                FXCollections.observableArrayList(controller.getPedidos());
        listPedidos.setItems(items);
        lblTotal.setText(String.format("Total acumulado: $%.0f", controller.getTotal()));
    }

    /** Expone la raíz para que MainApp la monte en el Scene. */
    public VBox getRoot() { return root; }
}
