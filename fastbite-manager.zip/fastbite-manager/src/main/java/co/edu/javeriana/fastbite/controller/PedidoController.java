package co.edu.javeriana.fastbite.controller;

import co.edu.javeriana.fastbite.model.GestorPedidos;
import co.edu.javeriana.fastbite.model.Pedido;

import java.util.List;

/**
 * Controlador MVC: recibe los eventos de la vista y coordina el modelo.
 * GRASP Controller — maneja los eventos del sistema (caso de uso: gestión de pedidos).
 * SOLID SRP        — responsabilidad única: coordinar vista y modelo.
 * SOLID DIP        — depende de GestorPedidos inyectado, no lo crea internamente.
 */
public class PedidoController {

    private final GestorPedidos gestor;

    /** SOLID DIP: la dependencia llega desde afuera (MainApp la inyecta). */
    public PedidoController(GestorPedidos gestor) {
        this.gestor = gestor;
    }

    /**
     * Maneja el evento 'Agregar Pedido'.
     * Valida los datos de entrada y delega la creación al modelo.
     *
     * @return true si el pedido fue agregado correctamente, false si hubo un error de validación.
     */
    public boolean agregarPedido(String cliente, String producto, String cantidadStr) {
        if (cliente == null || cliente.trim().isEmpty()) return false;
        if (producto == null || producto.isEmpty())       return false;
        try {
            int cantidad = Integer.parseInt(cantidadStr.trim());
            if (cantidad <= 0) return false;
            gestor.agregarPedido(cliente.trim(), producto, cantidad);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Maneja el evento 'Eliminar Pedido'.
     */
    public void eliminarPedido(Pedido pedido) {
        if (pedido != null) {
            gestor.eliminarPedido(pedido);
        }
    }

    // ── Métodos de consulta para la vista ──────────────────────────────────

    public List<Pedido>  getPedidos()            { return gestor.getPedidos();            }
    public List<String>  getProductosDisponibles(){ return gestor.getNombresProductos();   }
    public double        getTotal()               { return gestor.calcularTotal();         }
}
